"use strict";
process.title = 'node-gameserver';
var webSocketsServerPort = 8888;
var webSocketServer = require('websocket').server;

var http = require('http');
/**
 * Global variables
 */
// list of currently connected clients (users)
var clients = [ ];

/**
 * Helper function for escaping input strings
 */
function htmlEntities(str) {
  return String(str)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

var server = http.createServer(function(request, response) {});

server.listen(webSocketsServerPort, function() {
  console.log((new Date()) + " Game server listening on port " + webSocketsServerPort);
});

console.log("Server timeout: "+server.timeout);
server.timeout=90000;

/**
 * WebSocket server
 */
var wsServer = new webSocketServer({
  // WebSocket server is tied to a HTTP server. WebSocket
  // request is just an enhanced HTTP request. For more info 
  // http://tools.ietf.org/html/rfc6455#page-6
  httpServer: server
});
// This callback function is called every time someone
// tries to connect to the WebSocket server
wsServer.on('request', function(request) {
  console.log((new Date()) + ' Connection from origin '+request.origin+'.');
  var clientData = {
    connection: request.accept(null, request.origin),
	userName:	"?????",
	publicID:	""+Math.round(Math.random()*10000000),	// Used to send initial challenge to a client
	privateID: 	""+Math.round(Math.random()*10000000),	// Used to send in-game data to a client after challenge accepted - re-generated after each game
	pingTime:	(new Date()).getTime(),
	opponentIX:	-1
  };
  var index = clients.push(clientData)-1;
  clientData.index=index;
  
  console.log((new Date()) + ' Connection accepted. Total clients:'+(index+1));
  
  // user sent some message
  clientData.connection.on('message', function(message) {
	  try{
	    if (message.type === 'utf8') {
	      if(message.utf8Data.indexOf("|")>0){
	    	  
	    	var input=message.utf8Data.split('|');
	    	console.log("Input: ");
	    	console.log(input);

			let ms=(new Date()).getTime();

	    	switch(input[0]){	// 0 = command
	    	
	    	case 'P':
	    		{
	    			clientData.pingTime=ms;
	    			console.log((new Date()) + ' Ping at '+clientData.pingTime+' from: ' + clientData.userName);
	    			for (var i=0; i < clients.length; i++) {
	    				if(ms-clients[i].pingTime>(1000*90)){
	    					clients[i].connection.close();
	    					console.log("Kicked timed-out connection at index "+1);
	    					clients.splice(i, 1);
	    					--i;
	    				}
	    			}
	    		}
	    		break;
	    	case 'SET_NAME':
    			clientData.pingTime=ms;
	    		clientData.userName=input[1];
		        console.log((new Date()) + ' User is known as: ' + clientData.userName);
	    		break;

	    	case 'SET_PRIVATE_ID':
    			clientData.pingTime=ms;
	    		// If any other clients have the same private ID, they must be old connections, so kick them...
    			for (var i=0; i < clients.length; i++) {
    				if(clients[i].privateID==input[1]){
    					clients[i].connection.close();
    					console.log("Kicked old connection at index "+1);
    					clients.splice(i, 1);
    					--i;
    				}
    			}
    			
	    		clientData.privateID=input[1];
	    		
		        console.log((new Date()) + ' User ' + clientData.userName + ' set private ID to '+input[1]);
	    		break;

	    	case 'LIST':
	    		{
	    			clientData.pingTime=ms;
	    			var d="";
	    			for (var i=0; i < clients.length; i++) {
	    				if(clients[i].publicID!=clientData.publicID){
	  	          			d+=clients[i].userName+"|"+clients[i].publicID+'|';
	    				}
	  	        	}
	    			var json = JSON.stringify({ type:'msg', data: 'L|'+d.substring(0,d.length-1) });
	    			clientData.connection.sendUTF(json);
	    		}
	    		console.log((new Date()) + ' User requested client list: ' + clientData.userName);
	    		break;	
	    	case 'CHALLENGE':
	    		{
    				clientData.pingTime=ms;
	    			var d="";
	    			for (var i=0; i < clients.length; i++) {
	    				if(clients[i].publicID==input[1]){
	    					var json = JSON.stringify({ type:'msg', data: 'C|'+clientData.privateID+'|'+clientData.userName });
	    					clients[i].connection.sendUTF(json);
	    	    			break;
	    				}
	  	        	}
	    			
    			}
	    		break;
	    	case 'ACCEPT':
	    		{
    				clientData.pingTime=ms;
	    			var d="";
	    			for (var i=0; i < clients.length; i++) {
	    				if(clients[i].privateID==input[1]){
	    					var json = JSON.stringify({ type:'msg', data: 'A|'+clientData.privateID });
	    					console.log("Sending accept to: "+clients[i].userName);
	    					for(var r=0;r<3;r++)
	    						clients[i].connection.sendUTF(json);
	    	    			break;
	    				}
	  	        	}
	    			
				}
	    		break;
	    	case 'REJECT':
	    		{
    				clientData.pingTime=ms;
	    			var d="";
	    			for (var i=0; i < clients.length; i++) {
	    				if(clients[i].privateID==input[1]){
	    					var json = JSON.stringify({ type:'msg', data: 'R|'+clientData.privateID });
	    					for(var r=0;r<3;r++)
	    						clients[i].connection.sendUTF(json);
	    	    			break;
	    				}
	  	        	}
	    			
				}
	    		break;
	    	case 'INGAME':	// client is already in a game
	    		{
    				clientData.pingTime=ms;
	    			var d="";
	    			for (var i=0; i < clients.length; i++) {
	    				if(clients[i].privateID==input[1]){
	    					var json = JSON.stringify({ type:'msg', data: 'I|'+clientData.privateID });
	    					for(var r=0;r<3;r++)
	    						clients[i].connection.sendUTF(json);
	    	    			break;
	    				}
	  	        	}
	    			
				}
	    		break;
	    	case 'START':
	    		{
    				clientData.pingTime=ms;
	    			var d="";
	    			for (var i=0; i < clients.length; i++) {
	    				if(clients[i].privateID==input[1]){
	    					var json = JSON.stringify({ type:'msg', data: 'S|'+clientData.privateID });
	    					clients[i].opponentIX=clientData.index;
	    					clientData.opponentIX=clients[i].index;
	    					for(var r=0;r<3;r++){
	    						clients[i].connection.sendUTF(json);	// Start player 2
	    						clientData.connection.sendUTF(json);	// AND Start player 1 (even though this player initiated it, we tell it to start here to keep things in sync)
	    					}
	    	    			console.log((new Date()) +" Started game between "+clientData.userName+" ("+clientData.privateID+") and "+clients[i].userName+" ("+clients[i].privateID+")");
	    	    			break;
	    				}
	  	        	}
	    			
				}
	    		break;
	    	case 'ADD_ROW':	// format is ADD_ROW|{privateID}|{number of rows}
	    		{
	    			clientData.pingTime=ms;
	    			var d="";
	    			var sentRow=false;
	    			for (var i=0; i < clients.length; i++) {
	    				if(clients[i].privateID==input[1]){
	    					var json = JSON.stringify({ type:'msg', data: '+|'+clientData.privateID+'|'+input[2] });
	    	    			clients[i].connection.sendUTF(json);
	    	    			sentRow=true;
	    	    			break;
	    				}
	  	        	}
	    			if(!sentRow){	// other side has disconnected?
	    				var json = JSON.stringify({ type:'msg', data: 'W|'+clientData.privateID });
	    				lientData.connection.sendUTF(json);
	    			}
	    			
				}
	    		break;
	    	case 'YOU_WIN':	// Win (this client lost game - seems backward, but whatever :) )
	    		{
    				clientData.pingTime=ms;
	    			var d="";
	    			for (var i=0; i < clients.length; i++) {
	    				if(clients[i].privateID==input[1]){
	    					var json = JSON.stringify({ type:'msg', data: 'W|'+clientData.privateID });
	    					for(var r=0;r<3;r++)
	    						clients[i].connection.sendUTF(json);
	    	    			console.log((new Date()) +" "+clients[i].userName+" ("+clients[i].privateID+") won!");
	    	    			clients[i].opponentIX=-1;
	    	    			clientData.opponentIX=-1;
	    	    			break;
	    				}
	  	        	}
	    			
				}
	    		break;
	    	}
	    	
	      } else { // log and broadcast the message
	        console.log((new Date()) + ' Received Message from ' + clientData.userName + ': ' + message.utf8Data);
	        
	        // we want to keep history of all sent messages
	        var obj = {
	          text: htmlEntities(message.utf8Data),
	          userName: clientData.userName,
	        };
	
	        // broadcast message to all connected clients
	        var json = JSON.stringify({ type:'msg', data: obj });
	        for (var i=0; i < clients.length; i++) {
	          clients[i].connection.sendUTF(json);
	        }
	      }
	    }
	  }catch(e){
		  console.log("Exception: "+e.message);
	  }
  });
  // user disconnected
  clientData.connection.on('close', function(connection) {
    if (clientData.userName !== false){
      console.log((new Date()) + " Peer " + index + " disconnected.");
      // remove user from the list of connected clients
      clients.splice(index, 1);
    }
  });
});

